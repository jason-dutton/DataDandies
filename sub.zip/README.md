# DataDandies

<div align="center">

![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/jason-dutton/DataDandies/makefile.yml)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/jason-dutton/DataDandies)


</div>

GitHub repository for the 2023 entelect hackathon done by the Data Dandies

# Style Guide
Variables: snake_case
Functions: lowerCamelCase
Classes: UpperCamelCase

Indent: 2 spaces
